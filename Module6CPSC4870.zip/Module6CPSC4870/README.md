# Curling League Manager

## Description
This project is meant for organizing leagues and teams 
with in a single application for the game of curling. 

## Installation
Clone this repository and install the required dependencies from the requirements.txt file.

## Features
- Create and Manage individual curling leagues that are automatically saved to the "database"
- Within each league you can add and then edit teams.
- Each window should be exited since the functionality of having a close button was not included in the 
requirement description.

## Acknowledgements 
This is meant to be Module6 for Jonathan Elder in CPSC 4970.
