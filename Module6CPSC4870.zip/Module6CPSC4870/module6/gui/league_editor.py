from PyQt5.QtWidgets import QDialog, QVBoxLayout, QPushButton, QListWidget, QLineEdit, QMessageBox, QInputDialog
from PyQt5.QtCore import pyqtSlot
from module6.model.team import Team  # Ensure the Team class is correctly imported


class LeagueEditor(QDialog):
    def __init__(self, league, league_database):
        super(LeagueEditor, self).__init__()
        self.league = league
        self.league_database = league_database
        self.initUI()

    def initUI(self):
        self.setWindowTitle(f'Editing {self.league.name}')
        self.setGeometry(100, 100, 600, 400)  # Match the size to MainWindow

        layout = QVBoxLayout()

        self.list_widget = QListWidget()
        self.update_team_list()
        layout.addWidget(self.list_widget)

        self.btn_add_team = QPushButton('Add Team', self)
        self.btn_add_team.clicked.connect(self.add_team)
        layout.addWidget(self.btn_add_team)

        self.btn_delete_team = QPushButton('Delete Team', self)
        self.btn_delete_team.clicked.connect(self.delete_team)
        layout.addWidget(self.btn_delete_team)

        self.btn_edit_team = QPushButton('Edit Team', self)
        self.btn_edit_team.clicked.connect(self.edit_team)
        layout.addWidget(self.btn_edit_team)

        self.setLayout(layout)

    def update_team_list(self):
        self.list_widget.clear()
        for team in self.league.teams:
            self.list_widget.addItem(team.name)

    @pyqtSlot()
    def add_team(self):
        text, ok = QInputDialog.getText(self, 'Add Team', 'Enter team name:')
        if ok and text:
            try:
                new_team = Team(self.league_database.next_oid(), text)
                self.league.add_team(new_team)
                self.update_team_list()
                self.league_database.save("league_database.pkl")  # Save after adding
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    @pyqtSlot()
    def delete_team(self):
        item = self.list_widget.currentItem()
        if item:
            team_name = item.text()
            team = self.league.team_named(team_name)
            if team:
                try:
                    self.league.remove_team(team)
                    self.update_team_list()
                    self.league_database.save("league_database.pkl")  # Save after deletion
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))

    @pyqtSlot()
    def edit_team(self):
        item = self.list_widget.currentItem()
        if item:
            team_name = item.text()
            team = self.league.team_named(team_name)
            if team:
                from module6.gui.team_editor import TeamEditor  # Make sure this import is correctly placed to avoid circular imports
                editor = TeamEditor(team, self.league_database)
                editor.exec_()