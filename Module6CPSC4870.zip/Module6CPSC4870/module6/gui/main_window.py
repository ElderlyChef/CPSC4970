import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QAction, QFileDialog, QMessageBox, QListWidget, QInputDialog
from PyQt5.QtCore import pyqtSlot

from module6.gui.league_editor import LeagueEditor
from module6.model.league import League
from module6.model.league_database import LeagueDatabase


class MainWindow(QMainWindow):
    def __init__(self, league_database):
        super(MainWindow, self).__init__()
        self.league_database = league_database
        self.initUI()
        self.load_data()  # Automatically load data on initialization

    def initUI(self):
        self.setWindowTitle('Curling League Manager')
        self.setGeometry(100, 100, 600, 400)  # x, y, width, height

        # Central widget and layout
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)
        layout = QVBoxLayout(self.central_widget)

        # List widget to display leagues
        self.list_widget = QListWidget(self)
        layout.addWidget(self.list_widget)

        # Add, Delete, Edit buttons
        self.btn_add_league = QPushButton('Add League', self)
        self.btn_add_league.clicked.connect(self.add_league)
        layout.addWidget(self.btn_add_league)

        self.btn_delete_league = QPushButton('Delete League', self)
        self.btn_delete_league.clicked.connect(self.delete_league)
        layout.addWidget(self.btn_delete_league)

        self.btn_edit_league = QPushButton('Edit League', self)
        self.btn_edit_league.clicked.connect(self.edit_league)
        layout.addWidget(self.btn_edit_league)

        # Menu bar for load and save
        main_menu = self.menuBar()
        file_menu = main_menu.addMenu('File')

        load_action = QAction('Load', self)
        load_action.triggered.connect(self.load_data)
        file_menu.addAction(load_action)

        save_action = QAction('Save', self)
        save_action.triggered.connect(self.save_data)
        file_menu.addAction(save_action)

    def update_league_list(self):
        self.list_widget.clear()
        for league in self.league_database.leagues:
            self.list_widget.addItem(league.name)

    @pyqtSlot()
    def add_league(self):
        text, ok = QInputDialog.getText(self, 'Add League', 'Enter league name:')
        if ok and text:
            try:
                new_oid = self.league_database.next_oid()
                new_league = League(new_oid, text)
                self.league_database.add_league(new_league)
                self.update_league_list()
                self.league_database.save("league_database.pkl")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    @pyqtSlot()
    def delete_league(self):
        item = self.list_widget.currentItem()
        if item:
            league_name = item.text()
            league = self.league_database.league_named(league_name)
            if league:
                try:
                    self.league_database.remove_league(league)
                    self.update_league_list()
                    self.league_database.save("league_database.pkl")
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))

    @pyqtSlot()
    def edit_league(self):
        item = self.list_widget.currentItem()
        if item:
            league_name = item.text()
            league = self.league_database.league_named(league_name)
            if league:
                editor = LeagueEditor(league, self.league_database)
                editor.exec_()  # This will open the LeagueEditor as a modal dialog

    @pyqtSlot()
    def load_data(self):
        # Attempt to load the existing data
        self.league_database.load("league_database.pkl")
        self.update_league_list()

    @pyqtSlot()
    def save_data(self):
        file_name, _ = QFileDialog.getSaveFileName(self, "Save File", "", "League Files (*.lg)")
        if file_name:
            self.league_database.save(file_name)



if __name__ == '__main__':
    app = QApplication(sys.argv)
    league_db = LeagueDatabase.instance()  # Get the database instance
    league_db.load("league_database.pkl")  # Load the database from a file at startup
    ex = MainWindow(league_db)
    ex.show()
    sys.exit(app.exec_())