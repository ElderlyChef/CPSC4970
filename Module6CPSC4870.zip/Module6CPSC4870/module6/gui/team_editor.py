from PyQt5.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QLineEdit, QLabel, QMessageBox
from PyQt5.QtCore import pyqtSlot
from module6.model.team_member import TeamMember  # Ensure this class is correctly imported

class TeamEditor(QDialog):
    def __init__(self, team, league_database):
        super(TeamEditor, self).__init__()
        self.team = team
        self.league_database = league_database
        self.initUI()

    def initUI(self):
        self.setWindowTitle(f'Editing Members of {self.team.name}')
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.list_widget = QListWidget()
        self.list_widget.itemClicked.connect(self.populate_member_fields)
        self.update_member_list()
        layout.addWidget(self.list_widget)

        self.name_input = QLineEdit(self)
        self.email_input = QLineEdit(self)
        form_layout = QHBoxLayout()
        form_layout.addWidget(QLabel("Name:"))
        form_layout.addWidget(self.name_input)
        form_layout.addWidget(QLabel("Email:"))
        form_layout.addWidget(self.email_input)
        layout.addLayout(form_layout)

        self.btn_add_member = QPushButton('Add Member', self)
        self.btn_add_member.clicked.connect(self.add_member)
        layout.addWidget(self.btn_add_member)

        self.btn_delete_member = QPushButton('Delete Member', self)
        self.btn_delete_member.clicked.connect(self.delete_member)
        layout.addWidget(self.btn_delete_member)

        self.btn_update_member = QPushButton('Update Member', self)
        self.btn_update_member.clicked.connect(self.update_member)
        layout.addWidget(self.btn_update_member)

        self.setLayout(layout)

    def populate_member_fields(self, item):
        member_details = item.text().split(' <')
        member_name = member_details[0]
        member_email = member_details[1].rstrip('>')
        self.name_input.setText(member_name)
        self.email_input.setText(member_email)

    def update_member_list(self):
        self.list_widget.clear()
        for member in self.team.members:
            self.list_widget.addItem(f"{member.name} <{member.email}>")

    @pyqtSlot()
    def add_member(self):
        name = self.name_input.text()
        email = self.email_input.text()
        if name and email:
            if not any(m.name == name or m.email == email for m in self.team.members):
                new_member = TeamMember(self.league_database.next_oid(), name, email)
                self.team.add_member(new_member)
                self.league_database.save("league_database.pkl")
                self.update_member_list()
                self.name_input.clear()
                self.email_input.clear()
            else:
                QMessageBox.warning(self, "Duplicate Detected", "Each member's name and email must be unique.")

    @pyqtSlot()
    def delete_member(self):
        item = self.list_widget.currentItem()
        if item:
            member_name = item.text().split(' <')[0]
            member = self.team.member_named(member_name)
            if member:
                self.team.remove_member(member)
                self.league_database.save("league_database.pkl")
                self.update_member_list()

    @pyqtSlot()
    def update_member(self):
        item = self.list_widget.currentItem()
        if item and self.name_input.text() and self.email_input.text():
            member_name = item.text().split(' <')[0]
            member = self.team.member_named(member_name)
            if member and (member.name != self.name_input.text() or member.email != self.email_input.text()):
                if not any(m.name == self.name_input.text() or m.email == self.email_input.text() for m in self.team.members if m != member):
                    member.name = self.name_input.text()
                    member.email = self.email_input.text()
                    self.league_database.save("league_database.pkl")
                    self.update_member_list()
                else:
                    QMessageBox.warning(self, "Error", "Each member's name and email must be unique.")