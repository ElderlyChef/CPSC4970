# Jonathan Elder
# CPSC 4970 Module 6

import yagmail


class Emailer:
    """A singleton class for sending emails using Gmail."""

    _sole_instance = None
    sender_address = ""

    def __new__(cls, *args, **kwargs):
        """Ensure only one instance is created."""
        if not cls._sole_instance:
            cls._sole_instance = super(Emailer, cls).__new__(cls)
        return cls._sole_instance

    @classmethod
    def configure(cls, sender_address):
        """Configure the sender address for the emailer."""
        cls.sender_address = sender_address
        cls.yag = yagmail.SMTP(cls.sender_address)

    @classmethod
    def instance(cls):
        """Return the sole instance of the Emailer."""
        if not cls._sole_instance:
            cls._sole_instance = cls()
        return cls._sole_instance

    def send_plain_email(self, recipients, subject, message):
        """Email a list of recipients using yagmail/Gmail."""
        for recipient in recipients:
            self.yag.send(to=recipient, subject=subject, contents=message)
            print(f"Email sent to: {recipient}")
