# Jonathan Elder
# CPSC 4970 Module 6

class IdentifiedObject:
    """Represents an object with a unique identifier."""

    def __init__(self, oid):
        self._oid = oid

    @property
    def oid(self):
        return self._oid

    def __eq__(self, other):
        """Checks equality between object type and unique identifier."""
        return isinstance(other, type(self)) and self.oid == other.oid

    def __hash__(self):
        """Generates a hash code and ties it to the unique identifier."""
        return hash(self.oid)