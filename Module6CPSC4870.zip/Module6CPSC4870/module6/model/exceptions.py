# Jonathan Elder
# CPSC 4970 Module 6

class DuplicateOid(Exception):
    """Exception when trying to use a duplicate "oid"."""
    def __init__(self, oid):
        self.oid = oid
        super().__init__(f"Duplicate OID detected: {oid}")


class DuplicateEmail(Exception):
    """Exception when an email address already used is trying to be entered."""
    def __init__(self, email):
        self.email = email
        super().__init__(f"Duplicate email detected: {email.lower()}")