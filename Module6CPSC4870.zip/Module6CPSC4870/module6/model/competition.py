# Jonathan Elder
# CPSC 4970 Module 6

from module6.model.identified_object import IdentifiedObject


class Competition(IdentifiedObject):
    """Represents a competition between teams."""

    def __init__(self, oid, teams, location, date_time=None):
        """Initialize a competition."""
        super().__init__(oid)
        self._teams_competing = teams
        self.location = location
        self.date_time = date_time

    @property
    def teams_competing(self):
        """Returns the teams competing in a competition."""
        return self._teams_competing

    def send_email(self, emailer, subject, message):
        """Sends an email to all unique team members based on email in a competition."""
        recipients = set()
        for team in self._teams_competing:
            for member in team.members:
                if member.email:
                    recipients.add(member.email)
        emailer.send_plain_email(list(recipients), subject, message)

    def __str__(self):
        """Returns a string formatted for the competition."""
        date_str = self.date_time.strftime('%m/%d/%Y %H:%M') if self.date_time else "TBD"
        return f"Competition at {self.location} on {date_str} with {len(self._teams_competing)} teams"
