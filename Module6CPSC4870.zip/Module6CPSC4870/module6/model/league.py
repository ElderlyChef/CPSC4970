# Jonathan Elder
# CPSC 4970 Module 6

from module6.model.identified_object import IdentifiedObject
from module6.model.exceptions import DuplicateOid


class League(IdentifiedObject):
    """Represents a league, containing teams and competitions."""

    def __init__(self, oid, name):
        """Initializes a new League with a unique identifier and name."""
        super().__init__(oid)
        self.name = name
        self._teams = []
        self._competitions = []

    @property
    def teams(self):
        return self._teams

    @property
    def competitions(self):
        return self._competitions

    def add_team(self, team):
        """Adds a team to the league, checking for duplicate OIDs."""
        if any(t.oid == team.oid for t in self._teams):
            raise DuplicateOid(team.oid)
        self._teams.append(team)

    def remove_team(self, team):
        """Removes a team from the league if not currently involved in any competitions."""
        if any(team in competition.teams_competing for competition in self._competitions):
            raise ValueError("Cannot remove a team that is actively in a competition already.")
        if team in self._teams:
            self._teams.remove(team)

    def team_named(self, team_name):
        for team in self._teams:
            if team.name == team_name:
                return team
        return None

    def add_competition(self, competition):
        """Adds a competition to the league, ensuring all teams are league members."""
        if not all(team in self._teams for team in competition.teams_competing):
            raise ValueError("All teams within competition must already be apart of the league")
        self._competitions.append(competition)

    def teams_for_member(self, member):
        return [team for team in self._teams if member in team.members]

    def competitions_for_team(self, team):
        return [comp for comp in self._competitions if team in comp.teams_competing]

    def competitions_for_member(self, member):
        competitions = []
        for comp in self._competitions:
            for team in comp.teams_competing:
                if member in team.members:
                    competitions.append(comp)
                    break
        return competitions

    def __str__(self):
        return f"League Name: {self.name}, {len(self._teams)} teams, {len(self._competitions)} competitions"