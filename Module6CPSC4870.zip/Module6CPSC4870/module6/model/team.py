# Jonathan Elder
# CPSC 4970 Module 6

from module6.model.identified_object import IdentifiedObject
from module6.model.exceptions import DuplicateEmail, DuplicateOid


class Team(IdentifiedObject):
    """Represents a team."""

    def __init__(self, oid, name):
        """Initialize a new Team."""
        super().__init__(oid)
        self.name = name
        self._members = []

    @property
    def members(self):
        """Return a list of a team's members."""
        return self._members

    def add_member(self, member):
        """Add a member to the team, ensuring no duplicate emails or "iod"s."""
        if any(m.email.lower() == member.email.lower() for m in self._members if m.email):
            raise DuplicateEmail(member.email)
        if any(m.oid == member.oid for m in self._members):
            raise DuplicateOid(member.oid)
        self._members.append(member)

    def member_named(self, name):
        """Return a team member by name. Will return None if no name is equivalent."""
        for member in self._members:
            if member.name == name:
                return member
        return None

    def remove_member(self, member):
        """Remove a member from the team if they exist."""
        if member in self._members:
            self._members.remove(member)

    def send_email(self, emailer, subject, message):
        recipients = [member.email for member in self._members if member.email]
        emailer.send_plain_email(recipients, subject, message)

    def __str__(self):
        """Return a string with a team's name and its total members."""
        return f"Team Name: {self.name}, {len(self.members)} members"