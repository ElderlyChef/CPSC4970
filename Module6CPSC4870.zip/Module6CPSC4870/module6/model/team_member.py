# Jonathan Elder
# CPSC 4970 Module 6

from module6.model.identified_object import IdentifiedObject


class TeamMember(IdentifiedObject):
    """Represents a member of a team."""

    def __init__(self, oid, name, email):
        """Initializes a new TeamMember with unique identifier, name, and email."""
        super().__init__(oid)
        self.name = name
        self.email = email

    def send_email(self, emailer, subject, message):
        emailer.send_plain_email([self.email], subject, message)

    def __str__(self):
        """Return a string of the team_member in "Name<Email>" format."""
        return f"{self.name}<{self.email}>"