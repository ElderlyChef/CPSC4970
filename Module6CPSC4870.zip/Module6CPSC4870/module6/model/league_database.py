# Jonathan Elder
# CPSC 4970 Module 6

import pickle
import os
import csv

from module6.model.exceptions import DuplicateOid


class LeagueDatabase:
    """A singleton class to manage leagues using serialization with pickle."""

    _sole_instance = None

    def __new__(cls):
        """Ensure only one instance is created."""
        if not cls._sole_instance:
            cls._sole_instance = super(LeagueDatabase, cls).__new__(cls)
            cls._sole_instance._leagues = []
            cls._sole_instance._last_oid = 0
        return cls._sole_instance

    @classmethod
    def instance(cls):
        """Return the sole instance of the database."""
        return cls.__new__(cls)

    @classmethod
    def load(cls, file_name):
        """Load the database from a file, with a backup option."""
        try:
            with open(file_name, 'rb') as file:
                cls._sole_instance = pickle.load(file)
        except Exception:
            print("Error loading database. Attempting to load from backup.")
            try:
                with open(file_name + '.backup', 'rb') as file:
                    cls._sole_instance = pickle.load(file)
            except Exception:
                print("Failed to load the backup database.")

    @property
    def leagues(self):
        """Read-only property to access the list of leagues."""
        return self._sole_instance._leagues

    def add_league(self, league):
        """Add the specified league to the leagues list."""
        if any(l.oid == league.oid for l in self._sole_instance._leagues):
            raise DuplicateOid(league.oid)
        self._sole_instance._leagues.append(league)
        self._sole_instance._last_oid = max(self._sole_instance._last_oid, league.oid)

    def remove_league(self, league):
        """Remove the specified league from the leagues list."""
        if league in self._sole_instance._leagues:
            self._sole_instance._leagues.remove(league)

    def league_named(self, name):
        """Return the league with the given name or None of no such league exists."""
        for league in self._sole_instance._leagues:
            if league.name == name:
                return league
        return None

    def next_oid(self):
        """Generate the next object ID."""
        self._sole_instance._last_oid += 1
        return self._sole_instance._last_oid

    def save(self, file_name):
        """Save the database to a file, with a backup of the old file."""
        backup_file = file_name + '.backup'
        if os.path.exists(backup_file):
            os.remove(backup_file)  # Remove the existing backup file if it exists
        if os.path.exists(file_name):
            os.rename(file_name, backup_file)  # Only rename if the original file exists
        with open(file_name, 'wb') as file:
            pickle.dump(self._sole_instance, file)

    @staticmethod
    def import_league_teams(self, league, file_name):
        """Load the teams and team members in a league from a CSV formatted file."""
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                csv_reader = csv.reader(file)
                next(csv_reader)  # Skip header
                for row in csv_reader:
                    team_name, member_name, email = row
                    league.add_team(team_name, member_name, email)
        except Exception as e:
            print(f"Error importing teams: {e}")

    @staticmethod
    def export_league_teams(self, league, file_name):
        """Export the league's teams and members to a CSV file."""
        try:
            with open(file_name, 'w', newline='', encoding='utf-8') as file:
                csv_writer = csv.writer(file)
                csv_writer.writerow(['Team name', 'Member name', 'Member email'])
                for team in league.teams:
                    for member in team.members:
                        csv_writer.writerow([team.name, member.name, member.email])
        except Exception as e:
            print(f"Error exporting teams: {e}")