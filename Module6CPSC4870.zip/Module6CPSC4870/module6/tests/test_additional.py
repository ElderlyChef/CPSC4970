# Jonathan Elder
# CPSC 4970 Module 3

import unittest
from datetime import datetime
from module5.identified_object import IdentifiedObject
from module5.team_member import TeamMember
from module5.team import Team
from module5.league import League
from module5.competition import Competition
from module5.emailer import Emailer
from module5.exceptions import DuplicateEmail, DuplicateOid


class TestIdentifiedObject(unittest.TestCase):
    def test_comparison_with_non_identified_object_instances(self):
        obj = IdentifiedObject(1)
        self.assertNotEqual(obj, 1)
        self.assertNotEqual(obj, "test")


class TestTeamMember(unittest.TestCase):
    def test_attribute_changes(self):
        member = TeamMember(1, "Old Name", "old@example.com")
        member.name = "New Name"
        member.email = "new@example.com"
        self.assertEqual(member.name, "New Name")
        self.assertEqual(member.email, "new@example.com")


class TestTeam(unittest.TestCase):
    def test_add_same_member_multiple_times(self):
        team = Team(1, "Team")
        member = TeamMember(2, "Member", "member@example.com")
        team.add_member(member)  # First addition should succeed
        with self.assertRaises(DuplicateEmail):
            team.add_member(member)  # Attempt to add the same member again

    def test_send_email_no_members(self):
        team = Team(1, "Team")
        emailer = Emailer()
        try:
            team.send_email(emailer, "Subject", "Message")
        except Exception as e:
            self.fail(f"send_email raised an exception with no members: {e}")


class TestCompetition(unittest.TestCase):
    def test_competition_without_teams(self):
        comp = Competition(1, [], "Location", datetime.now())
        self.assertEqual(len(comp.teams_competing), 0)  # No teams in competition

    def test_email_sending_with_teams_having_no_members(self):
        team1 = Team(1, "Team1")
        team2 = Team(2, "Team2")
        comp = Competition(1, [team1, team2], "Location", datetime.now())
        emailer = Emailer()
        try:
            comp.send_email(emailer, "Subject", "Message")
        except Exception as e:
            self.fail(f"send_email raised an exception with teams having no members: {e}")


class TestLeague(unittest.TestCase):
    def test_removing_nonexistent_team(self):
        league = League(1, "League")
        team = Team(2, "Team")
        try:
            league.remove_team(team)  # Attempt to remove a team not in the league
        except Exception as e:
            self.fail(f"remove_team raised an exception with a non-existent team: {e}")



    def test_adding_competition_with_external_team(self):
        league = League(1, "League")
        internal_team = Team(1, "Internal Team")
        external_team = Team(2, "External Team")
        league.add_team(internal_team)
        competition = Competition(3, [internal_team, external_team], "Location", datetime.now())
        with self.assertRaises(ValueError):
            league.add_competition(competition)

    def test_removing_team_involved_in_competition(self):
        league = League(1, "League")
        team = Team(2, "Team")
        competition = Competition(3, [team], "Location", datetime.now())
        league.add_team(team)
        league.add_competition(competition)
        with self.assertRaises(ValueError):
            league.remove_team(team)


class TestEmailer(unittest.TestCase):
    def test_configuration_before_instance_creation(self):
        Emailer.configure("sender@example.com")
        self.assertEqual(Emailer.sender_address, "sender@example.com")

    def test_multiple_instance_creation_attempts(self):
        first_instance = Emailer.instance()
        second_instance = Emailer.instance()
        self.assertIs(first_instance, second_instance)


if __name__ == '__main__':
    unittest.main()
