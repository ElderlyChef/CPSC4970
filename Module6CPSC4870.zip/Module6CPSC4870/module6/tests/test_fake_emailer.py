import unittest
from tests.fake_emailer import FakeEmailer


class FakeEmailerTests(unittest.TestCase):
    class FakeEmailer:
        def __init__(self):
            self.recipients = None
            self.subject = None
            self.message = None

        def send_plain_email(self, recipients, subject, message):
            self.recipients = recipients
            self.subject = subject
            self.message = message

    def test_create(self):
        fe = self.FakeEmailer()
        self.assertIsNone(fe.recipients)
        self.assertIsNone(fe.subject)
        self.assertIsNone(fe.message)

    def test_send_plain_email(self):
        fe = self.FakeEmailer()
        recipients = ["email1@example.com", "email2@example.com"]
        subject = "Test Subject"
        message = "Test Message"
        fe.send_plain_email(recipients, subject, message)
        self.assertEqual(recipients, fe.recipients)
        self.assertEqual(subject, fe.subject)
        self.assertEqual(message, fe.message)


if __name__ == '__main__':
    unittest.main()
